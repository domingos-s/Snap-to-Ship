# Example Codex prompt

$snap-to-ship

Use the attached screenshot.
Mode: prototype
Fidelity: close

Build the landing page + a /dashboard that matches the screenshot. Use mocked data. Include loading/empty/error states.
