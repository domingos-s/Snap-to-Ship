# References

This skill assumes a Next.js + Tailwind + shadcn/ui stack.

If you're using the Codex CLI, you can attach image files (screenshots) as inputs and Codex can read them alongside your prompt.

Keep the build incremental and always run lint + build before handoff.
