# Routes Template

- / (landing)
- /dashboard (primary app)
- /settings (profile/preferences)
- /sign-in (optional)
- /sign-up (optional)
