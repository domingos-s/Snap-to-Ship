# Landing Page Template

Suggested sections:
1. TopNav with logo + CTA
2. Hero (headline, subhead, primary CTA, secondary CTA)
3. Social proof (logos or stats)
4. Feature grid (3–6 features)
5. How it works (3 steps)
6. Testimonials (optional)
7. Pricing (optional)
8. FAQ (optional)
9. Final CTA
10. Footer
